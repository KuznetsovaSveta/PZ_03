package com.metanit;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        // 1)	Написать программу, вводящую с клавиатуры число и выводящую сообщение «less», если его значение меньше 100, «not less» - иначе.
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();

        if (number < 100) {
            System.out.println("less");
        } else {
            System.out.println("not less");
        }

        //2)Написать программу, вводящую с клавиатуры - оценку (це1лое число от 2 до 5) и выводящую эту оценку словом (5 - отлично, 4 - хорошо, 3 - удовлетворительно, 2 - неудовлетворительно).
        Scanner console = new Scanner(System.in);
        // String name = scanner.nextLine();
        int n = console.nextInt();
        switch (n) {
            case 2:
                System.out.println("2 - неудовлетворительно");
                break;
            case 3:
                System.out.println("3 - удовлетворительно");
                break;
            case 4:
                System.out.println("4 - хорошо");
                break;
            case 5:
                System.out.println("5 - отлично");
                break;
            default:
                System.out.println("число не в диапозоне от 2 до 5");
        }

        //3)	Написать программу, которая по названию дня недели печатает его номер (воскресенье - 0, понедельник - 1, ..., суббота - 6)
        Scanner consolee = new Scanner(System.in);
        String str_day = consolee.next();
        switch (str_day) {
            case "Понедельник":
                System.out.println("1");
                break;
            case "Вторник":
                System.out.println("2");
                break;
            case "Среда":
                System.out.println("3");
                break;
            case "Четверг":
                System.out.println("4");
                break;
            case "Пятница":
                System.out.println("5");
                break;
            case "Суббота":
                System.out.println("6");
                break;
            case "Воскресенье":
                System.out.println("0");
                break;
            default:
                System.out.println("Введите корректное название дня недели");
        }

        //4)	Успеваемость студентов оценивается по 100-балльной шкале. Оценкам от 91 до 100 соответствует разряд А, от 81 до 90 — разряд В, и т. д., оценкам не более 50 — разряд F. Написать программу, вводящую с клавиатуры оценку по 100-балльной шкале и печатающую соответствующий ей разряд.
        System.out.println("Введите оценку");
        Scanner console_mark = new Scanner(System.in);
        int Mark = console_mark.nextInt();

        if ((Mark >= 91) && (Mark <= 100)) {
            System.out.println("Оценка:" + Mark + " соответствует разряду А");
        }
        if ((Mark >= 81) && (Mark <= 90)) {
            System.out.println("Оценка:" + Mark + " соответствует разряду B");
        }
        if ((Mark >= 71) && (Mark <= 80)) {
            System.out.println("Оценка:" + Mark + " соответствует разряду C");
        }
        if ((Mark >= 61) && (Mark <= 70)) {
            System.out.println("Оценка:" + Mark + " соответствует разряду D");
        }
        if ((Mark >= 51) && (Mark <= 60)) {
            System.out.println("Оценка:" + Mark + " соответствует разряду E");
        }
        if (Mark <= 50) {
            System.out.println("Оценка:" + Mark + " соответствует разряду F");
        }
        if (Mark > 100) {
            System.out.println("Оценки:" + Mark + " не существует");
        }

        //5.1 - Индивидуальное задание для бригад. Вариант №2
        double a = 8.53;
        double b = 17.1;
        //double x = 2.5;
        double x = -3.1;
        double y;


        if (x > 0) {
            y = (a + (1 / 2 * Math.pow(Math.E, -x)));
        } else {
            y = Math.cos(b * x + 1);
        }
        System.out.println("\nx = " + x + "\ny = " + y);

        //5.2 - Индивидуальное задание для бригад. Вариант №2


        double mm = 7.1;
        double nn = 6.7;
        double zz = -2.37;
        //double zz = -0.49;
        //double zz= 7,51
        double result;


        if (zz <= 0) {
            result = (mm + (1 / 2 * Math.pow(Math.E, -zz)));
        } else if ((0 < zz) && (zz < 4)) {
            result = Math.sin(Math.pow(nn, 2) * zz);
        } else {
            result = Math.sqrt(Math.pow(zz, 2) + 2 * mm);
        }

        System.out.println("\nresult = " + result);
    }
}
